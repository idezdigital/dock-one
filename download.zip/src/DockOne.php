<?php

namespace Idez\DockOne;

class DockOne
{
    // Build your next great package.
}
